package slinky.http;

public class X {
  private X() {
    throw new UnsupportedOperationException();
  }
}
