package slinky.http

import response.Response
import request.Request

/**
 * A web application that transforms a request to a response.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision<br>
 *          $LastChangedDate: 2008-12-06 20:12:43 +1000 (Sat, 06 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
trait Application[IN[_], OUT[_]] {
  /**
   * Transform the given request to a response.
   */
  def apply(implicit req: Request[IN]): Response[OUT]
}

/**
 * Functions over web applications that transforms a request to a response.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision<br>
 *          $LastChangedDate: 2008-12-06 20:12:43 +1000 (Sat, 06 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
object Application {
  /**
   * Create a web application from the given function.
   */
  def application[IN[_], OUT[_]](f: Request[IN] => Response[OUT]) = new Application[IN, OUT] {
    def apply(implicit req: Request[IN]) = f(req)
  }
}
