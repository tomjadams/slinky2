package slinky.http.request

import scalaz.list.NonEmptyList
import scalaz.list.NonEmptyList.nel
import scalaz.control.FunctorW._

/**
 * HTTP request URI.
 * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec5.html#sec5.1.2">RFC 2616 Section 5.1.2 Request-URI</a>.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision<br>
 *          $LastChangedDate: 2008-10-27 07:52:10 +1000 (Mon, 27 Oct 2008) $<br>
 *          $LastChangedBy: mtony $
 */
sealed trait Uri {
  /**
   * The path of this request URI.
   */
  val path: NonEmptyList[Char]

  /**
   * The query string of this request URI.
   */
  val queryString: Option[List[Char]]

  import Uri.uri

  /**
   * Returns a request URI with the given path and this query string.
   */
  def apply(p: NonEmptyList[Char]) = uri(p, queryString)

  /**
   * Returns a request URI with the given potential query string and this path.
   */
  def apply(q: Option[List[Char]]) = uri(path, q)

  /**
   * Returns a request URI after applying the given transformation to the path.
   */
  def +++(f: NonEmptyList[Char] => NonEmptyList[Char]) = uri(f(this.path), queryString)

  /**
   * Returns a request URI after applying the given transformation to the query string.
   */
  def ++++(f: Option[List[Char]] => Option[List[Char]]) = uri(path, f(this.queryString))

  import Util.{asHashMap, mapHeads}

  /**
   * Returns the query string split into values by <code>'='</code>.
   */
  lazy val parameters = queryString > (Util.parameters(_))

  /**
   * Returns the query string split into values by <code>'='</code> backed with a hash map.
   */
  lazy val parametersMap = parameters > (asHashMap[List, NonEmptyList](_))

  /**
   * Returns the query string split into values by <code>'='</code> (removing duplicate values for a given key) backed
   * with a hash map.
   */
  lazy val parametersMapHeads = parametersMap > (mapHeads(_))
}

/*
 * HTTP request URI.
 * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec5.html#sec5.1.2">RFC 2616 Section 5.1.2 Request-URI</a>.
 */
object Uri {
  /**
   * An extractor that always matches with the URI path and query string.
   */
  def unapply(uri: Uri): Option[(NonEmptyList[Char], Option[List[Char]])] =
    Some(uri.path, uri.queryString)

  /**
   * Constructs a URI with the given path and query string.
   */
  def uri(p: NonEmptyList[Char], s: Option[List[Char]]) = new Uri {
    val path = p
    val queryString = s
  }

  /**
   * Takes the given string and splits it into a URI and query string by <code>'?'</code> character.
   */
  implicit def ListUri(cs: List[Char]): Option[Uri] = cs match {
    case Nil => None
    case x :: _ if x == '?' => None
    case h :: t => {
      val z = t.break(_ == '?')
      Some(uri(nel(h, z._1), z._2 match {
        case Nil => None
        case _ :: Nil => None
        case _ :: k => Some(k)
      }))
    }
  }
}
